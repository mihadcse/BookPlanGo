package com.example.pomodoro;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.util.Timer;
import java.util.TimerTask;

public class Lab_07_2B_210041266_TimerController {

    @FXML
    private Label timerLabel;

    private Timer pomodoroTimer;

    private int minutes;
    private int seconds;

    public void initialize() {
        resetTimer();
    }

    @FXML
    public void onStartPomodoro() {
        startPomodoroTimer();
    }

    @FXML
    public void onStopPomodoro() {
        stopTimer();
    }

    @FXML
    public void onResetPomodoro() {
        resetTimer();
    }

    @FXML
    public void onStartShortBreak() {
        startShortBreakTimer();
    }

    @FXML
    public void onStartLongBreak() {
        startLongBreakTimer();
    }

    private void startTimer(int durationMinutes) {
        minutes = durationMinutes;
        seconds = 0;

        pomodoroTimer = new Timer();
        pomodoroTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    updateTimerLabel();
                });
                if (!decrementTime()) {
                    stopTimer();
                }
            }
        }, 0, 1000);
    }

    private void stopTimer() {
        if (pomodoroTimer != null) {
            pomodoroTimer.cancel();
            pomodoroTimer = null;
        }
    }

    private void resetTimer() {
        stopTimer();
        minutes = 0;
        seconds = 0;
        updateTimerLabel();
    }

    private void startPomodoroTimer() {
        startTimer(25);
    }

    private void startShortBreakTimer() {
        startTimer(5);
    }

    private void startLongBreakTimer() {
        startTimer(15);
    }

    private void updateTimerLabel() {
        timerLabel.setText(String.format("%02d : %02d", minutes, seconds));
    }

    private boolean decrementTime() {
        if (seconds > 0) {
            seconds--;
        } else {
            if (minutes > 0) {
                minutes--;
                seconds = 59;
            } else {
                return false;
            }
        }
        return true;
    }
}
